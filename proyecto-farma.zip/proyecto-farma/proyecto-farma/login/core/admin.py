from django.contrib import admin
from .models import  Producto, Egresos

# Registro de modelos para el administrador de Django.
class ProductoAdmin(admin.ModelAdmin):
    list_display = ( 'get_codigo_display', 
        'get_nombre_display', 
        'cantidad', 
        'fecha_vencimiento', 
        'get_categoria_display', 
        'precio_venta', 
        'get_refrigeracion_display')
    search_fields =('codigo', 'nombre')
    list_filter = ('codigo', 'nombre')
    
def get_codigo_display(self, obj):
        return obj.get_codigo_display()
    
def get_nombre_display(self, obj):
        return obj.get_nombre_display()

def get_categoria_display(self, obj):
        return obj.get_categoria_display()

def get_refrigeracion_display(self, obj):
        return obj.get_refrigeracion_display()

get_codigo_display.short_description = 'Codigo'
get_nombre_display.short_description = 'Nombre'
get_categoria_display.short_description = 'Categoria'
get_refrigeracion_display.short_description = 'Refrigeracion'   
    
    
       
class EgresoAdmin(admin.ModelAdmin):
    list_display = ( 'codigo', 'nombre', 'cantidad', 'motivo')
    search_fields =('codigo', 'nombre')
    list_filter = ('codigo', 'nombre')



admin.site.register(Producto, ProductoAdmin)
admin.site.register(Egresos, EgresoAdmin)


