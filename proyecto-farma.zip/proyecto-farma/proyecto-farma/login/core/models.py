from django.db import models

# Aqui creamos nuestros modelos

options =[
    [0, 'F-1'],
    [1, 'H-1'],
    [2, 'VS-1'],
    [3, 'D-1'],
    [4, 'CP-1'],
]

nombres_options =[
  [0, 'Aceite Mineral Chemo X 240mL'],
  [1, 'Acido Borico 100 G'],
  [2, 'Acetato De Aluminio Chemo 2.2 G X 50 Sobres (Ud)'],
  [3, 'AntifluDes X 120 caps (Ud)'],
  [4, 'Canesten V 200mg 3 Ovulos (caja)'],
  [5, 'Cardioaspirina 81mg X 30 tabs (caja)'],
  [6, 'Talerdin D X 50 Capsulas (Capsula)'],
  [7, 'Epival ER 500mg X 30 tabs'],
  [8, 'PERGOVERIS 75UI + 150U caja x 2 uds - FRIO - CP - FERTILIDAD'],
  [9, 'Cebion Naranja 500mg X 12 Sobres (Ud)'],
  [10, 'Acido Folico Raven 5mg X 30 tabs (caja)'],
  [11, 'Alergical Locion X 120mL'],
  [12, 'Centrum X 30 tabs'],
  [13, 'Ensure Advance Vainilla 400 G'],
  [14, 'Kalium 20 Mmol/15mL Jarabe 150mL'],
  [15, 'Sargenor Forte 5 Gr X 10 amp bebibles ( Unidad ) - CP'],
  [16, 'Immuvit Plus Q10 X 30'],
  [17, 'Dibase 10000 UI x 10 mL Solución Oral - CP'],
  [18, 'Dayamineral Jarabe 240mL'],
  [19, 'Babe Gel Aloe 100% 300mL'],
  [20, 'Sebamed Anti-Dry Crema Corporal Hidratante 200mL'],
  [21, 'Revita Tabletas F (DS Lab.)'],
  [22, 'Uriage Hyseac Mat 40 mL. - CP'],
  [23, 'La Roche-Posay Anthelios UVMUNE 400 SPF-50+locion 50 ML'],
  [24, 'Sophie Skin Protector Solar Facial Oil Balance SPF50 x 50 mL'],
  [25, 'Colgate Cepillo Dental Smile 6+ Anos'],
  [26, 'Crema de Rosas Fide Tubo 100G'],
  [27, 'Desinfectante Family Guard TO GO 55mL'],
  [28, 'Toallas Humedas Holder x 52 unidades'],
  [29, 'Colgate Kit Portatil'],
  [30, 'Nivea Crema Solida 20mL'],
  [31, 'Kin Cera Ortodontica normal'],
  [32, 'Blistex Lip Relief SPF 15'],
  [33, 'Betaserc 16mg X 20 tabs (unidad)'],
  [34, 'Teofilina Lisan 150mg X 30 tabs'],
]

categoria_options =[
  [0, 'Farmaceuticos'],
  [1, 'Hospitalarios'],
  [2, 'Vitaminas y Suplementos'],
  [3, 'Dermacosmetico'],
  [4, 'Cuidado Personal'],
]


refrigeracion_options =[
  [0, 'Si'],
  [1, 'No'],
]



  # Definimos la clase Producto que hereda de models.Model
class Producto(models.Model):
    codigo = models.IntegerField(choices=options, verbose_name="codigo")
    nombre = models.IntegerField(choices=nombres_options, verbose_name="nombre")
    cantidad = models.CharField(max_length=50)
    fecha_vencimiento = models.DateTimeField()
    categoria = models.IntegerField(choices=categoria_options, verbose_name="Categoria")
    precio_venta = models.IntegerField()
    refrigeracion = models.IntegerField(choices=refrigeracion_options, verbose_name="Refrigeracion")
    
def __str__(self):
        return f"{self.get_nombre_display()} ({self.get_codigo_display()})"

def get_nombre_display(self):
        return dict(nombres_options).get(self.nombre, "Unknown")
    
def get_codigo_display(self):
        return dict(options).get(self.codigo, "Unknown")
    
def get_categoria_display(self):
        return dict(categoria_options).get(self.categoria, "Unknown")
    
def get_refrigeracion_display(self):
        return dict(refrigeracion_options).get(self.refrigeracion, "Unknown")

#Modelos para Egresos    

Motivo_Egresos = [
    [0, 'Venta'],
    [1, 'Vencimiento'],
    [2, 'Dañado'],
    [3, 'Donación'],
    [4, 'Cambio'],
    [5, 'Consumo Interno'],
    [6, 'Muestras'],
    [7, 'Robo'],
    [8, 'Extraviado'],
    [9, 'Devolución'],
    [10, 'Producción'],
    [11, 'Transferencia entre almacenes'],
    [12, 'Liquidación'],
    [13, 'Promociones'],
    [14, 'Destrucción']
]

class Egresos(models.Model):
  codigo = models.IntegerField(choices=options, verbose_name="codigo")
  nombre = models.IntegerField(choices=nombres_options, verbose_name="nombre")
  cantidad = models.CharField(max_length=50)
  motivo = models.IntegerField(choices=Motivo_Egresos, verbose_name="motivos") 
    

def get_codigo_display(self):
        return dict(options).get(self.codigo, "Unknown")
    
def get_nombre_display(self):
        return dict(nombres_options).get(self.nombre, "Unknown")
      
def get_nombre_display(self):
        return dict(Motivo_Egresos).get(self.motivos, "Unknown")
    
def __str__(self):
    return self.nombre
