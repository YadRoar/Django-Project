"""
URL configuration for login project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
#En esta seccion es donde llamo mis paginas que se crearon en templates

from django.urls import path
from .views import home, egresos, ingresar, inventario, modificar, exit, editar_producto, editar_egreso, eliminar_egreso, eliminar_producto

urlpatterns = [
    path('', home, name='home'),
    path('egresos/', egresos, name='egresos'),
    path('ingresar/', ingresar, name='ingresar'),
    path('inventario/', inventario, name='inventario'),
    path('modificar/', modificar, name='modificar'),
    path('editar_producto/<int:pk>/', editar_producto, name='editar_producto'),
    path('logout/', exit, name='exit'),
    path('editar_egreso/<int:pk>/', editar_egreso, name='editar_egreso'),
    path('eliminar_egreso/<int:pk>/', eliminar_egreso, name='eliminar_egreso'),
    path('eliminar_producto/<int:pk>/', eliminar_producto, name='eliminar_producto'),
]
