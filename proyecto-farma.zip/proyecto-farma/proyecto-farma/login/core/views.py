
import pandas as pd
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.views import View
from .forms import ProductoForm, EgresoForm
from .models import Producto, Egresos


# Aqui creamos las vistas de nuestra aplicacion con una serie de sentencias necesarias para dar funcionamiento a la aplicacion
@login_required
def home(request):
    return render(request, 'core/home.html')

def egresos(request):
    egresos = EgresoForm()
    
    if request.method == 'POST':
        egresos = EgresoForm(request.POST)
        
        if egresos.is_valid():
            egresos.save()
            return redirect(reverse('egresos') + '?ok')
    
    return render(request, 'core/egresos.html', {'form_egreso': egresos })

def ingresar(request):
    producto = ProductoForm()
    
    if request.method == 'POST':
       producto = ProductoForm(data=request.POST) 
       
    if producto.is_valid():
        producto.save()
        return redirect(reverse('ingresar') + '?ok')
        
    return render(request, 'core/ingresar.html', {'form': producto})

def inventario(request):
    productos = Producto.objects.all()
    egresos = Egresos.objects.all()
    
    
    return render(request, 'core/inventario.html', {'productos': productos, 'egresos': egresos})
                  
def modificar(request):
    productos = Producto.objects.all()
    egresos = Egresos.objects.all()
        
    return render(request, 'core/modificar.html', {'productos': productos, 'egresos': egresos})

def editar_producto(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    form = ProductoForm(instance=producto)

    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('modificar')

    return render(request, 'core/editar_producto.html', {'form': form})

def exit(request):
    logout(request)
    return redirect('home')


def egreso_producto(request, id ):
    producto = get_object_or_404(Producto, id = id)
    producto.delete()
    return redirect('egresos')

def editar_egreso(request, pk):
    egreso = get_object_or_404(Egresos, pk=pk)
    form = EgresoForm(instance=egreso)

    if request.method == 'POST':
        form = EgresoForm(request.POST, instance=egreso)
        if form.is_valid():
            form.save()
            return redirect('inventario')

    return render(request, 'core/editar_egreso.html', {'form': form})

def eliminar_egreso(request, pk):
    egreso = get_object_or_404(Egresos, pk=pk)
    egreso.delete()
    return redirect('inventario')

def eliminar_producto(request, pk):
    egreso = get_object_or_404(Producto, pk=pk)
    egreso.delete()
    return redirect('inventario')

